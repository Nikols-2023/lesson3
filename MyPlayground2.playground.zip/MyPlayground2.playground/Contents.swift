import UIKit

//Int (целые числа)
var myInt: Int = 10 // переменная
let myConstantInt: Int = 20 // константа
//Double
let myConstantDouble: Double = 2.718 // константа
//Bool (логический тип)
var myBool: Bool = true // переменная
let myConstantBool: Bool = false // константа
//String (строки)
var myString: String = "Hello, World!" // переменная
let myConstantString: String = "Welcome!" // константа

//Приведение типа числа к строке:
let number: Int = 42
let stringNumber: String = String(number)
//Приведение строки к числу:
let string: String = "123"
let numberFromString: Int? = Int(string)
//Приведение числа с плавающей запятой к целому числу:
let doubleNumber: Double = 3.14
let intNumber: Int = Int(doubleNumber)
//Приведение целого числа к числу с плавающей запятой:
let intNumber: Int = 42
let doubleNumber: Double = Double(intNumber)
//Приведение числа к булевому типу:
let number: Int = 0
let isNonZero: Bool = Bool(number)
//Приведение булевого типа к числу:
let isTrue: Bool = true
let integerValue: Int = isTrue ? 1 : 0
//Приведение опционального значения к непосредственному значению:
let optionalNumber: Int? = 42
let unwrappedNumber: Int = optionalNumber!
//Приведение значения к опциональному типу:
let number: Int = 42
let optionalNumber: Int? = number as? Int

//пример математических вычислений с использованием операторов сложения, вычитания, умножения и деления:
let result = (3 + 2) * 5
print(result)

//С помощью if-else необходимо вывести в консоль, ночь ли сегодня (isNight)
let date = Date() // Получаем текущую дату и время
let calendar = Calendar.current // Получаем текущий календарь
let hour = calendar.component(.hour, from: date) // Получаем текущий час

if hour >= 18 || hour < 6 {
    print("Сегодня ночь (isNight)")
} else {
    print("Сегодня день (isDay)")
}

//Дана строка, сделать копию этой строки
let str1 = "Пример строки для копирования"
var str2 = ""
for char in str1 {
    str2.append(char)
}
print(str2)
